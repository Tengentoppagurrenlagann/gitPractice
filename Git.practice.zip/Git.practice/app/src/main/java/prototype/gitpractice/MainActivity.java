package prototype.gitpractice;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity {
    TextView displayMessage;
    byte iteration = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Declare button. Make button have a fade animation.
        Button displayButton = (Button)findViewById(R.id.display_button);
        Animation flashingFade = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.flashing_fade);
        displayButton.startAnimation(flashingFade);
    }



    public void display(View view)  //called when button is pushed
    {
        //output basic hello message unto screen
        String output = "HELLO \nMURICA.";
        displayMessage = (TextView)findViewById(R.id.output_text);
        displayMessage.setText(output);

        setIteration();
        theToasting();

    }
    private void setIteration()
    {
        if (iteration < 6 )
            iteration++;
        else
            iteration = 0;
    }

    private void theToasting()
    {
        String messagePiece[] = {"Hello", "Zach", "How", "Are", "You", "Doing", "?"};
        Toast popup = Toast.makeText(getApplicationContext(), messagePiece[iteration], LENGTH_SHORT);
        popup.show();
    }
}
